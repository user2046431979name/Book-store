export const BASE_URL = "https://baidt.pythonanywhere.com/api/";
