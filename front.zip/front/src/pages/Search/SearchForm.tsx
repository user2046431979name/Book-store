import React, { ChangeEvent, FormEvent, useState, useEffect } from "react";
import { Book, Category, SearchBook } from "../../type";
import searchSvg from "../../assets/Form/Search.svg";
import Select from "./Select";
import { useLocation } from "react-router-dom";

interface Props {
  searchResults: Book[];
  categories: Category[];
  onFormSubmit: (state: SearchBook) => void;
}

const SearchForm: React.FC<Props> = ({
  searchResults,
  categories,
  onFormSubmit,
}) => {
  const [category_id, setCategory] = useState("");
  const [title, setTitle] = useState("");

  const onChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    // setState((prev) => ({ ...prev, [name]: value }));
    onFormSubmit({
      title: "",
      category_id: "",
      [name]: value,
    });
  };
  const onCategoryChange = (e: ChangeEvent<HTMLSelectElement>) => {
    // const {value} = e.target;
    setCategory(e.target.value);
  };

  return (
    <>
      <form className="form">
        <Select
          onChange={onCategoryChange}
          searchResults={searchResults}
          categories={categories}
        />
        <div className="form__row">
          <input
            onChange={onChange}
            name="title"
            className="form__row-input"
            type="text"
          />
          <button type="submit" className="form__row-btn">
            <img src={searchSvg} alt="" />
          </button>
        </div>
      </form>
    </>
  );
};

export default SearchForm;
