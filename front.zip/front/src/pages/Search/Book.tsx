import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import React, { useEffect } from "react";
import { useLocation } from "react-router-dom"; // Import useLocation
import { useAppDispatch } from "../../app/redux";
import Card from "../../components/Card/Card";
import { getCategories, useCategories } from "../../slice/category";
import {
  getNextSearchs,
  getPreviousSearchs,
  setSearch,
  useSearch,
} from "../../slice/search";
import { SearchBook } from "../../type";
import SearchForm from "./SearchForm";
import { getBooks, useBooks } from "../../slice/book";

const Book: React.FC = () => {
  const dispatch = useAppDispatch();
  const { list: books } = useBooks();
  const { list: categories } = useCategories();
  const { list, pagination, currentPage } = useSearch();
  const location = useLocation();

  useEffect(() => {
    dispatch(getBooks());
    dispatch(setSearch(null));
    dispatch(getCategories());
  }, [dispatch]);

  useEffect(() => {
    dispatch(setSearch({}));
  }, [location, dispatch]);

  const onSearchSubmit = (search: SearchBook) => {
    dispatch(setSearch(search));
  };

  const handleNext = () => {
    if (pagination.next) {
      dispatch(getNextSearchs(pagination.next));
    }
  };

  const handlePrevious = () => {
    if (pagination.previous) {
      dispatch(getPreviousSearchs(pagination.previous));
    }
  };

  return (
    <div className="search container">
      {books.length === 0 ? (
        <h1>Книг пока что нет</h1>
      ) : (
        <>
          <SearchForm
            searchResults={list}
            onFormSubmit={onSearchSubmit}
            categories={categories}
          />
          <div className="container">
            <div className="row">
              {list.map((search) => (
                <div className="col-4" key={search.id}>
                  <Card book={search} />
                </div>
              ))}
            </div>
            <div className="pagination">
              <button onClick={handlePrevious} disabled={!pagination.previous}>
                <ArrowBackIcon />
              </button>
              <p>{currentPage}</p>
              <button onClick={handleNext} disabled={!pagination.next}>
                <ArrowForwardIcon />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Book;
